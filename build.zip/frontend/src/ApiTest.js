import React, { useState } from 'react';
import { getTestData, getTestData2 } from './api';

function ApiTest() {
  const [data, setData] = useState(null);
  const [ip,setIP] = useState('');

  const fetchData = async () => {
    try {
      const response = await getTestData();
      setData(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
  const fetchData2 = async () => {
    try {
      const response2 = await getTestData2();
      setIP(response2?.data?.IPv4);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <div>
      <h1>API Test App</h1>
      <button onClick={fetchData}>Fetch Data</button>
      {data && (
        <>
        <div>
          <h2>Data from API:</h2>
          <pre>{JSON.stringify(data, null, 2)}</pre>
        </div>
        <div>
          <p>IP</p>
          <p>{ip}</p>
          </div>
          </>
      )}
    </div>
  );
}

export default ApiTest;