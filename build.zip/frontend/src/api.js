import axios from 'axios';

const instance = axios.create({
  baseURL: 'http://10.129.245.143:8000', // Replace with your API endpoint
});

export const getTestData = () => instance.get('/api/test/');

const instance2 = axios.create({
  baseURL: 'https://geolocation-db.com'
});

export const getTestData2 = () => instance2.get('/json/');