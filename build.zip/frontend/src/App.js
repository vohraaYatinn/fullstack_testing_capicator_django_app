import React from 'react';
import ApiTest from './ApiTest';

function App() {
  return (
    <div className="App">
      <ApiTest />
    </div>
  );
}

export default App;